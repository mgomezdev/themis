# Browser fixture: installation responses use the shared mock API.
